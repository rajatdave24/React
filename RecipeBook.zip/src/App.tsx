import React, {Component} from 'react';
import Modal from './components/Modal';
import {recipeLists} from './Data/data';

class App extends React.component{

  constructor(props){
    super(props);

    this.state = {
      showModal: false,
      recipes: recipeLists,
      instruction: undefined,
      ingredients: undefined,
      search: '',
      mode: -1
    };

      this.handleAdd = this.handleAdd.bind(this);
      this.handleModal = this.handleModal.bind(this);
      this.handleCancel = this.handleCancel.bind(this);
      this.handleOnChange = this.handleOnChange.bind(this);
      this.handleView = this.handleView.bind(this);

  }

  handleModal = () => {

  }

  handleCancel = () => {

  }

  handleOnChange = () => {

  }

  handleAdd = () => {

  }

  handleView = () => {

  }

  render(){
    return(
      <div>HARE KRISHNA!!!</div>
    );
  }


}

export default App;