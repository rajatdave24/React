import React, {Component} from 'react';

export default class Modal extends React.Component{
  constructor(props){
    super(props);
  }
 
  remder(){
    return(
      <div>
        {this.props.children}
      </div>
    );
  }
}