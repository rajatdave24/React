const recipeLists = [
  {title: 'Krishna Prasadam', ingredients: 'BG 9.26, BG 3.14',instruction:'Offering with Love and Devotion'},
  {title: 'Krishna Prasadam', ingredients: 'BG 9.26, BG 3.14',instruction:'Offering with Love and Devotion'},
  {title: 'Krishna Prasadam', ingredients: 'BG 9.26, BG 3.14',instruction:'Offering with Love and Devotion'},
  {title: 'Krishna Prasadam', ingredients: 'BG 9.26, BG 3.14',instruction:'Offering with Love and Devotion'},
  {title: 'Krishna Prasadam', ingredients: 'BG 9.26, BG 3.14',instruction:'Offering with Love and Devotion'},
  {title: 'Krishna Prasadam', ingredients: 'BG 9.26, BG 3.14',instruction:'Offering with Love and Devotion'},
]